# Step 09 — Trust, contact and conversion

## Objective
Increase qualified enquiries without adding new pages, pop-ups, forms, testimonials or sales pressure.

## Implemented changes

1. Added a compact proof line in the hero:
   - Bachelor of Education
   - Certified German educator
   - Vienna and online

2. Strengthened the About section with a concise professional profile:
   - formal qualification
   - teaching formats and client contexts
   - working languages

3. Clarified the commercial pathway:
   - initial clarification
   - clear proposal
   - agreement on scope and conditions before booking

4. Added a fit filter:
   - coherent programmes rather than isolated lessons
   - regular, prepared work
   - willingness to use German between sessions
   - no premature result guarantees

5. Improved the email conversion path:
   - prefilled subject and structured message prompts
   - no external form, tracking or unnecessary data collection
   - three explicit next steps after first contact

## What was deliberately not added

- testimonials without verified permission
- invented client logos or success figures
- urgency language
- discounts or artificial scarcity
- an intrusive booking widget
- WhatsApp as a floating conversion device
- a long FAQ

## Result
The site now establishes credibility earlier, explains who the programme is for, makes the enquiry easier to write and tells visitors what will happen after they contact Lukas. It remains restrained and consistent with the one-page V3 principle.
