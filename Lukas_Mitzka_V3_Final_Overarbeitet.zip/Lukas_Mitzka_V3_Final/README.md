# Lukas Mitzka Education — V3 Final Candidate

A deliberately reduced English one-page website built with Eleventy.

## Structure
- `/en/` — main website
- `/en/imprint.html` — legal placeholder
- `/en/privacy.html` — privacy placeholder
- `/` — redirect to `/en/`

## Local use
```bash
npm ci
npm run build
npm run validate
npm start
```

## Publication warning
The project currently contains `noindex,nofollow` and a site-wide robots block because the legal pages are placeholders. Do not remove those protections until the imprint and privacy policy are complete and reviewed.

## Final design rules
- English only in the initial release
- One focused main page
- Imprint and Privacy as the only separate content pages
- Tailored German as the central brand principle
- No floating WhatsApp button
- No FAQ accordion, catalogue structure or unnecessary interface features
