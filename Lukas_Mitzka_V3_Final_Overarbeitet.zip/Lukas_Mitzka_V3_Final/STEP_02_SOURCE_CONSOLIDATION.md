# STEP 02 - SOURCE CONSOLIDATION

**Project:** Lukas Mitzka Education - V3 Final  
**Status:** Completed  
**Date:** 2026-07-12

## 1. Binding governing principle

The following principle overrides every contradictory instruction in older prompts, audits, requirement matrices, builds and source files:

1. V3 remains the technical basis.
2. The first final release is English only.
3. Almost all decision-relevant information belongs on one focused main page.
4. Only Imprint and Privacy remain separate pages.
5. No floating WhatsApp button.
6. No unnecessary dropdowns, accordions or feature collections.
7. Use the real LM signet.
8. `TAILORED GERMAN` is the central brand principle.
9. The page tells one short, logical story instead of presenting a catalogue of services.
10. Source material may supply facts, ideas and quality criteria, but may not override this architecture.

## 2. Final source hierarchy

### Level A - binding decisions

1. The governing principle above.
2. The fixed ten-step improvement plan.
3. Confirmed business facts and assets supplied by Lukas.
4. Decisions explicitly made during the current V3 Final process.

### Level B - technical source of truth

- `Lukas_Mitzka_V3_Final_Working_Source`
- Eleventy static site architecture
- Existing responsive image derivatives
- Existing build and validation scripts

This is the codebase to be improved. It is not automatically the final visual or editorial solution.

### Level C - factual and strategic reference

- `Lukas_Mitzka_Education_PROJECT_TRUTH_AND_REQUIREMENTS.md`
- `DEFINITION_OF_DONE.md`
- `ASSET_AND_DATA_GAPS.md`
- `RISK_REGISTER.md`
- Confirmed information contained in the current website

These files may provide business facts, risks and test criteria. Their older structural assumptions are not binding.

### Level D - visual and quality reference

- `Superprompt_V7.2_Darkmode_Immersive_OnePage_Visual_Rebuild_157_Seiten.pdf`
- `V7.2_VISUAL_REBUILD_ADDENDUM_WITH_EMBEDDED_ASSETS.docx`
- `SUPERPROMPT_12_PERFECTION_REBUILD.md`

Use these selectively for visual quality, responsive behaviour, typography, motion restraint, accessibility and asset handling. Do not reproduce their excessive process, page count or requirement volume.

### Level E - historical comparison only

- `lukas_mitzka_website_v3.zip`
- older multilingual and multi-page structures
- previous prompts, audits and generated documentation

These sources may reveal useful wording or mistakes to avoid. They do not control the final architecture.

## 3. Consolidated content truth

### Brand

- Public brand: **Lukas Mitzka Education**
- Central principle: **TAILORED GERMAN**
- Core service: personally planned German language training
- Positioning: a credible, personally led education boutique, not a language-school catalogue or coaching brand
- Visual direction: deep blue navy, warm cream, restrained steel blue and muted bronze
- Tone: precise, calm, intelligent, direct and credible

### Audience

Primary audience:

- adults
- international professionals and expats
- academics, entrepreneurs and internationally mobile adults
- adults who need German for professional, academic, everyday or personal purposes
- pairs or small private constellations when appropriate
- organisations with a concrete training need

The site must not assume that every client is pursuing career advancement. Life in Vienna, independence and precise personal expression are equally legitimate goals.

### Delivery

- Vienna and online
- private training is central
- professional communication can be integrated
- intensive programmes may be offered
- organisational training may be offered
- format, rhythm and content depend on the actual goal and starting point

### Method

The usable method logic is:

1. clarify the real goal
2. identify the current usable level and obstacles
3. select relevant situations and material
4. define a realistic format
5. review progress and adapt

This logic must be communicated as a coherent narrative, not as five identical cards or an inflated proprietary framework.

### Credibility

- Lukas must appear as a real person through authentic portraits and concrete, verifiable experience.
- No invented testimonials, success figures, client logos or prestige claims.
- Qualifications must be described accurately and only as strongly as the evidence permits.
- The About section must support the buying decision, not reproduce a full CV.

### Contact

- Primary public contact currently available: `info.lukasmitzka@gmail.com`
- A transparent email route is preferable to a fake or technically unconfirmed form.
- No floating WhatsApp control.
- WhatsApp may only be introduced later if the real business number and its role are confirmed.

## 4. Content that will be retained and improved

- Immediate explanation of private German training for adults
- Vienna and online availability
- Real-use orientation
- Tailoring based on goal, level, context, format and progress
- Private, intensive and organisational use cases
- A short working process
- A concise About and credibility section
- Practical information needed before an enquiry
- A strong email-based final CTA
- Imprint and Privacy links

## 5. Content that will be merged

- Purpose, Level, Context, Format and Progress become one coherent `Tailored German` chapter.
- Private training and professional communication are not presented as competing products.
- Pair training is treated as a possible format, not a separate service universe.
- Vienna orientation, cultural context and professional language appear as relevant applications, not standalone pages.
- Practical details and enquiry guidance are combined near the final conversion point.
- Repeated explanations of personalisation, structure and relevance are reduced to one strong explanation each.

## 6. Content and structures that are rejected

- nine-page or similarly broad bilingual site architecture
- German version in the first final release
- separate service, method, resources, process, corporate or biography pages
- six or more equal offer cards
- a visible catalogue of every possible learner type or training scenario
- repeated `Goal -> Programme -> Progress` diagrams or generic process graphics
- five identical cards for Purpose, Level, Context, Format and Progress
- floating WhatsApp controls
- FAQ accordions used to hide essential commercial information
- decorative dropdowns or interactions without a clear user need
- artificial portraits, stock-learning imagery and fake testimonials
- historical imagery as the dominant theme
- ornamental motion, particles, WebGL, scroll-jacking or cursor gimmicks
- black-and-gold luxury clichés
- excessive white or empty space used as a substitute for hierarchy
- copying all 1,055 historical requirements into the implementation backlog
- documentation output that becomes larger than the website itself

## 7. Asset decisions

### Approved for active use

- `lm-logo.svg` as the currently available real LM signet
- studio portrait and its AVIF/WebP derivatives
- Arkadenhof portrait and its AVIF/WebP derivatives

### Conditional use

- historical motifs may be used only selectively, subtly and after source/right status is acceptable
- `social-card.svg` may be revised later for metadata use

### Not yet evidenced

- original camera files for portraits
- open logo source beyond SVG
- reliable screenshots of the current site at target widths

The absence of camera originals does not block the redesign because usable high-resolution portrait files and web derivatives are available. It does prevent claiming that they are untouched original exports.

## 8. Superseded requirements

The following older requirements are explicitly superseded for this phase:

- final German and English copy parity
- visible language switcher
- German index, imprint and privacy output
- the fixed thirteen-part section sequence from the old Definition of Done
- a requirement to preserve every V7 section as a separate viewport
- a contact form as a mandatory feature
- optional future Corporate or About pages
- any requirement that creates a service catalogue rather than a focused narrative

Technical quality requirements remain useful where they do not conflict with the simplified architecture, especially:

- semantic HTML
- keyboard access
- visible focus
- reduced-motion support
- no-JavaScript readability
- responsive image delivery
- mobile-specific composition
- contrast and zoom checks
- performance and broken-link checks
- correct canonical, sitemap, robots, CNAME and 404 handling

## 9. Open factual decisions - not structural blockers

These must be resolved before final publication, but they do not change the governing architecture:

1. Exact final public qualification wording.
2. Exact price or package information, if any is shown.
3. Final legal operator details for Imprint.
4. Final Privacy wording based on actual hosting and services.
5. Whether a normal in-page WhatsApp text link is ever added.
6. Exact training radius and logistical limits for in-person sessions.
7. Whether historical motifs have adequate rights documentation.

Until confirmed, the website must use accurate neutral wording and must not invent details.

## 10. Single consolidated editorial rule

Every piece of source information must pass four tests before it appears on the page:

1. Is it true and verifiable?
2. Does a prospective client need it before making an enquiry?
3. Does it add something not already stated?
4. Can it be expressed more clearly and briefly?

If any answer is no, the content is removed, merged or kept only as internal background.

## 11. Step 2 decision

The project now has one coherent source basis. The large historical prompt system is no longer treated as a list of equal obligations. The next step may define the final positioning and core message without reopening the site architecture.
