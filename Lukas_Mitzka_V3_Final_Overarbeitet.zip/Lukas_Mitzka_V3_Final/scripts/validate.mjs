import fs from 'node:fs';
import path from 'node:path';
const root='_site';
const required=['en/index.html','en/imprint.html','en/privacy.html','index.html','404.html','robots.txt','sitemap.xml'];
let errors=[];
for(const f of required){if(!fs.existsSync(path.join(root,f))) errors.push(`missing ${f}`)}
const html=fs.readFileSync(path.join(root,'en/index.html'),'utf8');
for(const token of ['noindex,nofollow','<details class="mobile-menu"','class="skip"','id="approach"','id="training"','id="about"','id="contact"','portrait-studio','portrait-arcade']) if(!html.includes(token)) errors.push(`en: missing ${token}`);
for(const forbidden of ['href="/de/"','Purpose</p>','id="process"','button secondary','floating-whatsapp']) if(html.includes(forbidden)) errors.push(`en: forbidden legacy token ${forbidden}`);
if(/<form\b/i.test(html)) errors.push('en: unexpected form');
if((html.match(/<h1\b/g)||[]).length!==1) errors.push('en: expected exactly one h1');
if((html.match(/<section\b/g)||[]).length!==7) errors.push('en: expected exactly seven sections');
if(errors.length){console.error(errors.join('\n'));process.exit(1)}
console.log('Static validation passed.');
