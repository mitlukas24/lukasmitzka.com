# Schritt 1 – Technische Bestandsaufnahme

## Verbindliche Entscheidung

Als technische Arbeitsbasis wird der spätere One-Page-Quellstand aus
`Lukas_Mitzka_Education_CURRENT_SOURCE_BUILD_AND_STATUS.zip` verwendet.

Die ältere Datei `lukas_mitzka_website_v3.zip` bleibt ausschließlich als Vergleichs-, Text- und Ideenquelle erhalten. Ihre zweisprachige Mehrseitenarchitektur wird nicht weitergeführt.

## Warum dieser Stand gewinnt

- Er folgt bereits grundsätzlich der fokussierten One-Page-Logik.
- Er besitzt eine wartbare Eleventy-Quellstruktur statt nur statischer Einzelseiten.
- Er enthält optimierte Porträtdateien als AVIF und WebP in mehreren Größen.
- Er enthält getrennte englische Haupt-, Imprint- und Privacy-Templates.
- Die vorhandene statische Validierung läuft erfolgreich durch.
- Er lässt sich kontrolliert umbauen, ohne die verworfene Mehrseitenstruktur mitzuschleppen.

## Was erhalten bleibt

- Eleventy 3.1.2 als schlanke Build-Basis
- `src/en.njk` als Ausgangspunkt der englischen Hauptseite
- `src/en-imprint.njk` und `src/en-privacy.njk`
- responsive Porträt-Derivate in AVIF und WebP
- CNAME, 404-Seite, Sitemap und Robots-Datei als technische Grundlage
- vorhandene reduzierte JavaScript-Basis, sofern sie nach dem Umbau noch erforderlich ist

## Was überarbeitet wird

- gesamte visuelle Ausarbeitung
- Hero und Markenführung
- Sektionsdramaturgie und Textmenge
- Navigation und Calls-to-Action
- Typografie, Abstände, Raster, Bildzuschnitte und Übergänge
- mobile Darstellung
- Metadaten, SEO-Texte und Social Preview
- Kontaktabschluss
- Legal-Seiten, sobald reale Angaben bestätigt sind

## Was entfernt oder nicht übernommen wird

- deutsche Website in der ersten finalen Fassung
- About-, Contact-, Corporate-, Process-, Resources- und Training-Einzelseiten der älteren V3
- schwebender WhatsApp-Button
- Akkordeons, Dropdowns und unnötige Interaktionsmodule
- Angebotskatalog mit vielen gleichwertigen Karten
- dekorative Funktionen ohne klaren Nutzen
- künstliche oder nicht freigegebene Bildmotive
- alte Strategie- und Auditdateien aus dem späteren Produktivpaket

## Technische Risiken

1. Die finalen Legal-Angaben sind noch nicht vollständig bestätigt.
2. Reale Browser-Screenshots für Desktop und Mobil fehlen.
3. Das vorhandene Logo ist nur als aktuelles SVG vorhanden; eine offene Quelldatei fehlt.
4. Bei den Porträts ist nicht sicher, ob es Kamera-Originale oder bereits bearbeitete Exporte sind.
5. Historische Motive besitzen keinen abschließend dokumentierten Rechte- und Quellenstatus.
6. Der aktuelle Build ist technisch valide, aber gestalterisch noch kein freigegebenes Endprodukt.

## Ergebnis

Schritt 1 ist abgeschlossen. Die weitere Arbeit erfolgt ausschließlich auf einer Kopie des Eleventy-One-Page-Quellstands. Die alte V3 wird nicht überschrieben und nicht als strukturelle Grundlage verwendet.
