# Final revision

Final editorial and technical refinement of V3.

## Changed
- Shortened abstract and repetitive passages across the approach and training sections.
- Added a compact hero format line for Vienna, online, private and organisational training.
- Rephrased the qualification statement to specify the Bachelor of Education and completed specialist DaF/DaZ training.
- Rebuilt Practical Fit as a quickly scannable Who / Where / How block.
- Simplified the contact copy and added a prefilled enquiry email structure.
- Added the publication year to the footer.
- Preserved the fixed seven-section architecture and all V3 principles.

## Verification
- Eleventy production build passed.
- Static validation passed.
- Legal pages remain deliberate placeholders and the site remains noindex until reviewed legal content is supplied.
