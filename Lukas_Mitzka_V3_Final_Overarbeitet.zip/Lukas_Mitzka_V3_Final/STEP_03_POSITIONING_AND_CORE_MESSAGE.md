# STEP 03 - POSITIONING AND CORE MESSAGE

**Project:** Lukas Mitzka Education - V3 Final  
**Status:** Completed  
**Date:** 2026-07-12

## 1. Binding positioning statement

**Lukas Mitzka Education provides personally planned German training for adults who need the language to work in specific professional, academic and everyday situations.**

The service is positioned between two weak alternatives:

- it is more focused and personally guided than a standard language-school course
- it is more systematic and educationally credible than loose conversation coaching

The defining value is not luxury styling, unlimited flexibility or a proprietary method. It is the quality of the planning: the programme begins with what German must make possible, identifies the barriers that matter, and organises systematic language work around those priorities.

## 2. Central brand principle

# TAILORED GERMAN

`TAILORED GERMAN` means:

- the goal determines the order of work
- the learner's usable ability matters more than a level label alone
- relevant situations shape materials and practice
- grammar, vocabulary, pronunciation and skills remain systematic
- the format must be realistic enough to sustain
- progress is reviewed and priorities are adjusted

It does **not** mean:

- improvised lessons without a curriculum
- satisfying every preference without professional judgement
- guaranteeing rapid fluency
- a luxury lifestyle service
- generic coaching language with German as a backdrop
- an inflated branded framework with many named stages

## 3. Primary audience

The primary audience is:

- internationally mobile adults in Vienna or online
- professionals, academics and entrepreneurs
- adults who need greater independence and precision in German
- people whose needs are too specific, urgent or context-dependent for a generic course sequence
- organisations seeking relevant German training for a concrete role or task

The audience is defined by the **specificity of the need**, not by wealth, nationality, job title or an expat stereotype.

## 4. Core problem

Many adult learners do not primarily lack access to more German content. They lack a clear order of priorities.

Their knowledge is often uneven:

- they understand more than they can say under pressure
- everyday conversation works, but professional writing does not
- grammar is familiar, but not reliably available in real use
- a course level may be broadly correct while the actual situations remain insufficiently addressed

A standard sequence can provide useful structure, but it cannot by itself decide what this individual person should work on first.

## 5. Core promise

**German training is planned around what the learner needs to do, what already works and what currently prevents reliable communication.**

This is a process promise, not a guaranteed outcome promise.

The website may promise:

- a clear starting-point analysis
- reasoned priorities
- systematic and relevant language work
- transparent programme structure
- direct feedback
- regular review and adjustment

The website may not promise:

- fluency within a fixed period
- a guaranteed CEFR level increase
- effortless learning
- universal availability or unlimited flexibility
- outcomes not supported by evidence

## 6. Differentiation

The service is differentiated through five connected qualities:

1. **Personally led**  
   The person presented on the website is also responsible for the educational work.

2. **Purpose-led**  
   The programme begins with a concrete use of German rather than an abstract wish to improve.

3. **Systematic**  
   Relevant training does not abandon grammar, vocabulary, pronunciation, reading, writing, listening or speaking. It orders them intelligently.

4. **Context-aware**  
   Meetings, academic work, life in Vienna, formal writing and examinations require different language and different forms of practice.

5. **Adaptive but not arbitrary**  
   Progress and new demands can change the priorities, while the programme retains a coherent plan.

## 7. Message hierarchy

Every major page element must support this order:

### Message 1 - What is offered?

Personally planned German training for adults in Vienna and online.

### Message 2 - Why is it different?

The programme is built around real situations, current usable ability and the barriers that matter most.

### Message 3 - Is it still systematic?

Yes. Grammar, vocabulary, pronunciation and language skills are selected and sequenced according to the goal rather than removed from the process.

### Message 4 - Who is it for?

Adults with a concrete professional, academic, everyday or personal need, as well as organisations with a defined training objective.

### Message 5 - What happens next?

The prospective client describes the goal, starting point, context and timeframe. A suitable structure and conditions are then proposed.

## 8. Binding concise brand language

### Brand descriptor

**Personally planned German training for adults.**

### Expanded descriptor

**Personally planned German training for adults in Vienna and online, built around the situations in which the language actually has to work.**

### Primary value proposition

**Your goal sets the direction. Your current ability defines the starting point. The programme connects both through focused, systematic language work.**

### Core question

**What should German make possible next?**

This question may be used as a recurring narrative anchor, but not repeated excessively.

### Supporting line

**A clear programme for the German you need to use.**

## 9. Tone of voice

The final copy must be:

- precise
- calm
- intelligent
- direct
- adult
- concrete
- confident without exaggeration

The final copy must avoid:

- generic premium language
- motivational coaching clichés
- repeated references to transformation, confidence or unlocking potential
- exaggerated exclusivity
- academic over-explanation
- defensive disclaimers in every section
- long lists of every possible learner and scenario
- vague claims such as `bespoke excellence`, `language journey`, `world-class` or `master German`

## 10. Editorial boundaries

The website is **not** positioned as:

- a conventional language school
- a marketplace tutor profile
- a mass-market online course
- a general life or career coaching service
- a cultural concierge service for wealthy expats
- a corporate training agency with a large team
- a guaranteed exam-results provider

The website is positioned as a **small, personally led education practice with professional planning and a clearly defined scope**.

## 11. Commercial implication

The positioning supports a higher-than-marketplace price only when the website demonstrates:

- individual preparation
- coherent programme design
- relevant expertise
- reliable communication
- professional boundaries
- a credible real person

The site must not try to justify pricing through decorative luxury signals alone. Perceived value must come from clarity, relevance and trust.

## 12. Decision test for later steps

Every section, sentence, visual element and interaction must pass this test:

1. Does it make the offer easier to understand?
2. Does it demonstrate personally planned, systematic relevance?
3. Does it strengthen trust in Lukas as the actual educator?
4. Does it help a suitable adult decide whether to enquire?
5. Is it more useful than the space and attention it consumes?

If not, it is removed.

## 13. Step 3 decision

The final V3 will communicate one core idea:

> **German training should not merely follow the next chapter. It should follow a clear purpose, while retaining the systematic work needed to make progress reliable.**

This positioning is binding for the remaining steps. Later copy may refine wording, but it may not change the strategic meaning.
