# STEP 05 — User Journey and Section Flow

## Binding objective

The homepage must guide a serious prospective client through one continuous decision sequence:

1. understand the offer
2. recognise why it may be relevant
3. understand how it is planned
4. identify the suitable collaboration format
5. trust the person behind it
6. check practical fit
7. make contact

The page must not behave like a brochure, a course catalogue or a collection of unrelated visual moments. Each section must answer the next question created by the previous section.

## Primary visitor

The primary visitor is an adult who needs German for a concrete professional, academic or everyday purpose and is considering a personally led, paid programme in Vienna or online.

Typical states on arrival:
- knows what situation is difficult but not what training format is appropriate
- is dissatisfied with generic courses or loosely structured tutoring
- wants a serious, personal offer without navigating a large language-school website
- needs enough evidence and practical clarity to decide whether making contact is worthwhile

The visitor is not expected to understand teaching terminology. The website must speak in terms of tasks, barriers, priorities and use.

## Core conversion

The single primary conversion is an email enquiry.

### Binding CTA wording

**Discuss your German goals**

This wording is used consistently in:
- header CTA
- hero CTA
- final contact section

No competing CTA such as “Book now”, “Learn more”, “View programmes” or “Get started” will be added.

Anchor links may support orientation, but they are navigation, not competing conversions.

## Final section flow

### 1. Hero — Orientation

**Visitor question:** What is this, is it relevant to me, and what should I do next?

**Required response:**
- TAILORED GERMAN is visible as the brand principle
- personally planned German training is named directly
- adults, Vienna and online are clear
- the distinction from a standard course is understandable without reading further
- one portrait creates immediate personal presence
- one CTA offers the next step

**What the visitor should think:**
“This is a serious personal German-training offer for situations like mine.”

**Transition to next section:**
The hero establishes the promise. The next section must justify why tailoring matters, not repeat the offer.

### 2. Why tailored — Relevance

**Visitor question:** Why would I need this instead of a normal course or tutor?

**Required response:**
- standard sequences can be useful but do not know the visitor’s priorities
- tailored does not mean improvised or unsystematic
- the order of learning is determined by what must work in real life
- the explanation remains compact and concrete

**What the visitor should think:**
“My issue is not simply ‘improve German’; the order and focus matter.”

**Transition to next section:**
Once the need for tailoring is credible, the page must show how it is done without turning into a methodology lecture.

### 3. How the programme is planned — Comprehension

**Visitor question:** What does tailored planning actually involve?

**Required response:**
The five factors appear as one coherent sequence:
1. Goal
2. Current ability
3. Real situations
4. Suitable format
5. Review and adjustment

The layout must support reading in order. It may use restrained numbering, editorial rhythm or a vertical progression. It must not use five detached product cards, an accordion or a decorative app-style timeline.

Each factor receives:
- one short label
- one precise statement
- at most one compact explanatory paragraph

**What the visitor should think:**
“This is personalised, but there is a clear professional system behind it.”

**Transition to next section:**
After understanding the planning logic, the visitor is ready to identify the relevant form of collaboration.

### 4. Ways to work together — Self-selection

**Visitor question:** Which form of training fits my situation?

**Required response:**
Exactly three options:
- Private Training
- Intensive Programmes
- Training for Organisations

Each option must answer:
- when it is appropriate
- what makes it distinct
- who typically initiates or books it

Use cases such as professional communication, relocation, Vienna orientation, exams, pairs or onboarding are included within these three options. They must not become additional equal-level offers.

The options may be visually differentiated, but they must not look like aggressively priced product cards. No individual CTA button is required on every option.

**What the visitor should think:**
“I can see where my situation belongs without having to decode a catalogue.”

**Transition to next section:**
The visitor now understands the offer. The next question is whether Lukas is credible and personally suitable.

### 5. About Lukas — Trust

**Visitor question:** Who will actually provide the training, and why should I trust the work?

**Required response:**
- an authentic second portrait
- a concise professional introduction
- verified education and experience only
- concrete description of preparation, teaching and review
- personal tone without autobiography or self-congratulation

Qualifications must not be reduced to vague phrases such as “passionate educator”. Conversely, the section must not become a CV dump.

**What the visitor should think:**
“This is personally led by someone who combines teaching experience with a structured approach.”

**Transition to next section:**
Trust is followed by practical qualification. The website should now help the visitor decide whether an enquiry is sensible.

### 6. Practical fit — Qualification

**Visitor question:** Is this realistically available and suitable for me?

**Required response:**
A compact set of clear conditions:
- Vienna and online
- adults as the principal audience
- coherent programmes rather than isolated ad-hoc lessons
- scope, format and commercial conditions agreed before the start
- no guaranteed result or timeframe before assessment

This section should reduce unsuitable enquiries without sounding defensive. It must not introduce new philosophical claims or repeat the method.

If verified pricing is later included, it belongs here in a concise form. The section must still work without a price table.

**What the visitor should think:**
“This appears to fit my situation, and I understand the basic conditions.”

**Transition to next section:**
No further persuasion layer is needed. The page moves directly to contact.

### 7. Contact and footer — Action

**Visitor question:** What do I send, and what happens first?

**Required response:**
- direct invitation framed around the visitor’s goal
- email as the primary route
- a short list in sentence form of useful initial information: goal, current level, relevant situations, Vienna or online, approximate timeframe
- Imprint and Privacy links

The final section must feel conclusive. It must not open another content branch, introduce another offer or add a newsletter, social-feed block or floating contact tool.

**What the visitor should think:**
“I know exactly what to write, and making contact is low-friction.”

## Navigation behaviour

### Desktop

Order:
- Approach → section 2 or beginning of sections 2–3
- Training → section 4
- About → section 5
- Contact → section 7

The logo links to the top. The header CTA links to Contact.

### Mobile

The same four links are used in the same order. No nested navigation, no language switch and no duplicate menu structures. The menu closes after a selection.

### Sticky behaviour

A restrained sticky header is acceptable if it remains compact and does not obscure content. It must not become a persistent promotional banner.

## CTA distribution

The primary CTA appears only at decisive points:
- header
- hero
- final contact section

It is intentionally absent from every methodology factor and every training format. Repetition of buttons throughout the page would make the offer feel transactional and visually noisy.

A subtle text link from the training section to contact is optional only if testing shows that the page requires it. It is not part of the default build.

## Reading rhythm

The page should alternate between:
- concise positioning
- explanatory content
- visual/person-based trust
- practical information

Binding rhythm rules:
- no two long text-heavy sections without a visual or spatial change
- no section begins by repeating the previous section’s conclusion
- headings must advance the argument, not merely label topics
- each primary section should communicate its main point in roughly 10–20 seconds of scanning
- full comprehension must remain possible without animations

## Visual transition logic

Transitions should support the narrative rather than create spectacle for its own sake.

Approved principles:
- controlled changes in background tone
- overlap or cropping around portrait sections
- editorial numbering in the planning sequence
- restrained lines, rules or typographic shifts
- subtle reveal motion with reduced-motion support

Rejected patterns:
- unrelated “wow” effects between every section
- horizontal scroll for core content
- carousels
- app dashboards
- progress meters that imply a guaranteed learner journey
- decorative animations that delay access to text

## Decision points and exits

A visitor may be ready to enquire after the hero, after recognising a training format or after reading practical fit. The persistent header CTA provides access without placing buttons inside every section.

The page does not need artificial retention devices. A visitor who determines that the offer is not suitable should be able to leave with a clear understanding rather than being pushed through repeated conversion prompts.

## Mobile priority

On mobile, the narrative order remains unchanged. No content is hidden simply to shorten the page.

Priority rules:
- headline and CTA before the first portrait is fully visible if screen height is limited
- planning factors remain vertically sequential
- collaboration formats stack in the same order
- portraits use intentional crops and do not dominate multiple consecutive screens
- contact email remains easy to tap and copy

## Accessibility and interaction

- semantic section headings follow a logical hierarchy
- anchor targets account for the sticky header
- keyboard users can reach navigation and CTA controls in a predictable order
- motion is supplementary and disabled or reduced when requested by the operating system
- contact information is available as visible text, not only inside an icon
- portrait alternative text is informative only where the image conveys identity; purely decorative repetitions may use empty alt text

## Content handoff to Step 06

Step 06 must write the final English copy against this exact journey. It must not add new sections or revive removed content.

Required copy groups:
1. hero lock-up, headline, lead and CTA context
2. compact “Why tailored” argument
3. five planning-factor texts
4. three collaboration-format texts
5. concise About text with verified evidence
6. practical-fit statements
7. final contact invitation

## Binding summary

The final page is a controlled argument:

**Offer → relevance → method → suitable format → trust → fit → contact**

Every element that does not move the visitor through that sequence must be removed, merged or treated as secondary decoration.
