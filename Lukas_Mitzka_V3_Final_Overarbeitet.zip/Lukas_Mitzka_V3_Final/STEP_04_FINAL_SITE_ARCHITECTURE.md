# STEP 04 — Final Site Architecture

## Binding decision

V3 will consist of exactly three public pages:

1. `/en/` — the complete English main page
2. `/en/imprint.html` — imprint
3. `/en/privacy.html` — privacy

The German version, language switch, German legal pages, separate offer pages, resource pages, process pages and other historical branches are not part of the first final V3 release.

## Final homepage structure

The homepage will contain exactly seven primary sections in this order.

### 1. Hero
**Function:** Immediate orientation and positioning.

Must answer within the first screen:
- what is offered
- for whom
- where
- why it is different from a standard language course
- what the next step is

Required elements:
- LM signet / brand lock-up
- “TAILORED GERMAN” as the central brand principle
- one precise headline
- one short explanatory paragraph
- one primary CTA
- one selected portrait

No secondary CTA, no language switch, no carousel and no decorative feature list.

### 2. Why tailored
**Function:** Establish the problem with standardised teaching and explain the core principle.

This section replaces the current separate “Starting point” introduction and prevents the site from beginning with a long methodology lecture.

It should explain in compact form:
- standard sequences can provide structure but cannot determine one learner’s priorities
- tailored does not mean improvised
- the learner’s goal determines the order of systematic language work

### 3. How the programme is planned
**Function:** Explain the planning logic once, clearly and visually.

The current five full sections — Purpose, Level, Context, Format and Progress — are merged into one coherent section.

The five factors remain present, but not as five long chapters:
1. Goal
2. Current ability
3. Real situations
4. Suitable format
5. Review and adjustment

They may appear as a vertical sequence, compact editorial blocks or another restrained layout. They must not become five cards, an accordion or an app-like process component.

### 4. Ways to work together
**Function:** Help visitors recognise the relevant collaboration model without turning the page into an offer catalogue.

Exactly three formats:
- Private Training
- Intensive Programmes
- Training for Organisations

Each format receives:
- one clear use case
- one short explanation
- a restrained indication of whom it suits

Pair training, professional communication, relocation, exam preparation, Vienna orientation and similar topics are integrated as use cases. They do not receive separate offer cards or pages.

### 5. About Lukas
**Function:** Create personal trust and professional credibility.

Required elements:
- one authentic portrait
- concise professional introduction
- verified experience and qualifications only
- teaching philosophy expressed through concrete practice, not self-praise

No “evidence” placeholder language, no invented numbers, no testimonial substitute and no oversized biography.

### 6. Practical fit
**Function:** Pre-qualify enquiries and remove basic uncertainty.

This compact section covers only the information a serious prospective client needs before contacting:
- Vienna and online
- adults as the primary target group
- coherent programmes rather than isolated ad-hoc lessons
- scope and conditions discussed transparently before the start
- no guaranteed outcome before the starting point is assessed

Pricing information will be included only if a verified, current pricing decision is available by the content stage. The architecture does not depend on a price table.

### 7. Contact and footer
**Function:** Convert interest into one clear next step.

Required elements:
- one direct question or invitation
- a short indication of what to include in the first message
- email as the primary contact route
- Imprint and Privacy links

WhatsApp may be mentioned only if it is intentionally approved later. It will not appear as a floating button.

## Navigation

Desktop navigation is reduced to four anchors:
- Approach
- Training
- About
- Contact

The header contains:
- brand / LM signet
- four anchor links
- one primary CTA

The language switch is removed.

The mobile navigation uses the same items. No nested menu and no dropdown.

## Elements removed from the current architecture

The following current elements are removed or merged:
- separate full sections for Purpose, Level, Context, Format and Progress
- duplicate eyebrow labels
- separate “Working Process” section with four generic steps
- “About and Evidence” placeholder framing
- long definition-list treatment of practical details
- secondary hero CTA
- German language switch and German branch
- repeated explanations of planning, review and tailoring

The useful substance from these elements is retained inside the seven-section structure.

## Page-length rule

The homepage must feel complete but finite. It should not read like a condensed brochure containing every historical requirement.

Binding limits:
- seven primary homepage sections
- three collaboration formats
- one primary CTA wording used consistently
- no FAQ section in the first final version
- no separate testimonials section without genuine testimonials
- no resources, blog or downloads section
- no additional page unless legally required

## Narrative sequence

The final story is:

1. This is the offer.
2. This is why a standard sequence may not be enough.
3. This is how tailored planning remains systematic.
4. These are the three sensible ways to work together.
5. This is the person and professional basis behind the work.
6. This is the practical fit.
7. This is the next step.

Every later content and design decision must support this sequence.
