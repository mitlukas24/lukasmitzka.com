# Step 06 — Final English Copy

Status: binding copy deck for implementation in Step 08.

This copy follows the fixed seven-section architecture. It replaces the current long-form Purpose / Level / Context / Format / Progress sequence and all duplicate headings, repeated eyebrow labels and secondary hero CTAs.

---

## Global navigation

**Brand:** LUKAS MITZKA EDUCATION  
**Brand principle:** TAILORED GERMAN

Navigation:
- Approach
- Training
- About
- Contact

Primary CTA:
- **Discuss your German goals**

---

## 1. Hero

**Eyebrow**  
TAILORED GERMAN

**Headline**  
German training built around what you need to do.

**Lead**  
Personally planned training for adults, professionals and international clients in Vienna and online. The programme starts with your real goals, your current ability and the situations in which German has to work.

**Primary CTA**  
Discuss your German goals

**Portrait alt text**  
Lukas Mitzka, German educator in Vienna

---

## 2. Why tailored

**Eyebrow**  
WHY TAILORED

**Headline**  
A standard sequence cannot know what matters first.

**Body**  
A course book can provide structure. It cannot decide whether your immediate priority is contributing in meetings, writing with greater precision, preparing for an exam or handling everyday life in Vienna with more confidence.

Tailored does not mean improvised. It means that systematic work on grammar, vocabulary, pronunciation and language skills is arranged around what German needs to make possible next.

---

## 3. How the programme is planned

**Eyebrow**  
THE APPROACH

**Headline**  
Personal in focus. Systematic in structure.

**Intro**  
The programme is planned through five connected decisions. Together, they define what receives attention, in which order and in which form.

### 01 — Goal
**What should German make possible next?**  
A clear purpose determines the immediate priorities. That may mean participating more confidently in meetings, settling into life in Vienna, preparing for a defined exam or expressing complex ideas with greater precision.

### 02 — Current ability
**What already works, and where does communication still break down?**  
A level label is only a reference. The starting point is based on usable strengths and recurring barriers, so time is not spent repeating what is already secure.

### 03 — Real situations
**Where, with whom and under what pressure does German have to work?**  
Relevant situations shape the register, vocabulary, reaction time and practice required. A presentation, a formal email and a conversation at an authority do not demand the same language.

### 04 — Suitable format
**Which rhythm and setting are effective and realistic?**  
The programme is adapted to the available time, desired intensity and scope for independent work. Training may take place in Vienna or online, continuously or in a concentrated phase.

### 05 — Review
**What has improved, and what deserves attention next?**  
Priorities are reviewed through actual use and recurring difficulties. The structure remains clear, but it is adjusted when progress or new demands make a change sensible.

**Closing line**  
The result is not a fixed package imposed in advance, but a coherent programme with a clear direction.

---

## 4. Ways to work together

**Eyebrow**  
TRAINING

**Headline**  
Three formats. One planning principle.

### Private Training
**For sustained development centred on one person’s real use of German.**  
Private training combines systematic language development with focused preparation for professional, academic and everyday situations. It is suitable when priorities need to be developed, tested in real life and refined over time.

Typical contexts include professional communication, life in Vienna, academic language and recurring barriers in speaking or writing. Training may also be arranged for two people with closely aligned goals.

### Intensive Programmes
**For a defined period in which concentrated progress matters.**  
An intensive programme is suitable before a move, a new role, an examination, a project or another time-sensitive transition. The work is deliberately focused and requires sufficient time both during and between sessions.

The scope is agreed only after the goal, current level and realistic workload have been established.

### Training for Organisations
**For employees who need German in specific professional situations.**  
Training for organisations is planned around actual roles, communication tasks and workplace contexts rather than a generic business-language syllabus. It may focus on meetings, presentations, written communication, onboarding or practical integration in Vienna.

The programme can be coordinated with the organisation while keeping the language work relevant to the participants themselves.

---

## 5. About Lukas

**Eyebrow**  
ABOUT

**Headline**  
Serious preparation, clear explanations and language that has to work outside the lesson.

**Body**  
I am a certified German educator based in Vienna. I hold a Bachelor of Education and have taught adults, international professionals, intensive-course participants and company clients in individual and group settings.

My work combines structured language teaching with close attention to the situations in which a learner actually needs German. Sessions are prepared around clear priorities, but they remain responsive to what emerges in real communication. Grammar is explained precisely, vocabulary is developed in context and recurring difficulties are addressed rather than worked around.

The aim is not to make lessons appear effortless. It is to make the work focused, understandable and useful.

**Portrait alt text**  
Lukas Mitzka in the Arkadenhof of the University of Vienna

---

## 6. Practical fit

**Eyebrow**  
PRACTICAL FIT

**Headline**  
Clear conditions before the programme begins.

**Body**  
Training is available for adults in Vienna and online, depending on format and availability. The work is organised as a coherent programme rather than as isolated, unconnected lessons.

Before the start, we clarify the goal, current level, relevant situations, preferred format and realistic timeframe. Scope and commercial conditions are then agreed in advance. A specific result or completion date cannot be guaranteed before the starting point and available workload have been assessed.

---

## 7. Contact

**Eyebrow**  
CONTACT

**Headline**  
Tell me what German needs to make possible.

**Body**  
A useful first message can be brief. Include your goal, your approximate current level, the situations in which you need German, whether you prefer Vienna or online, and your intended timeframe.

**Primary CTA**  
Discuss your German goals

**Visible email**  
info.lukasmitzka@gmail.com

**Supporting line**  
I will reply with an initial assessment of whether the format is suitable and what the next step should be.

**Footer links**  
Imprint · Privacy

**Footer line**  
© Lukas Mitzka Education

---

## Metadata

**Page title**  
Tailored German training in Vienna and online | Lukas Mitzka Education

**Meta description**  
Personally planned German training for adults, professionals and international clients in Vienna and online, built around real goals and situations.

**Open Graph title**  
Tailored German training | Lukas Mitzka Education

**Open Graph description**  
Personally planned German training for adults and professional contexts in Vienna and online.

---

## Editorial rules fixed by this copy deck

- “TAILORED GERMAN” is a brand principle, not a decorative slogan repeated throughout the page.
- “Personally planned” is preferred to vague claims such as “fully bespoke”, “exclusive” or “premium”.
- The copy does not promise a level, result or timeframe.
- No invented testimonials, client counts, success rates or institutional endorsements are used.
- No paragraph repeats the previous section’s conclusion.
- No additional service category may be introduced beside the three defined formats.
- Professional, academic, relocation, examination, pair and Vienna-related use cases remain examples within the three formats.
- The CTA wording remains “Discuss your German goals”.
- The public copy remains English-only in this version.
