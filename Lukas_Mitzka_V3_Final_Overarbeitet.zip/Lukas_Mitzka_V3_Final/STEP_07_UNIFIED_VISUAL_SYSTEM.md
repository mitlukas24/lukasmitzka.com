# STEP 07 — UNIFIED VISUAL SYSTEM

Status: **LOCKED**

This document defines the final visual system for V3. It replaces conflicting visual instructions from older prompts. Later implementation may refine measurements for technical reasons, but it may not introduce a second design language.

## 1. Visual objective

The site must feel:

- calm, precise and highly considered
- premium through restraint, proportion and typography rather than decoration
- personal enough for private clients, but professional enough for corporate decision-makers
- recognisably connected to Vienna and education without becoming nostalgic, academic or tourist-like

It must not feel like:

- a generic language school
- a SaaS landing page
- a luxury-fashion imitation
- a coaching funnel
- a portfolio overloaded with animation
- an interface assembled from unrelated cards

## 2. Core art direction

The final direction is a **warm dark editorial design**.

The dark background creates focus and distinction. Cream typography prevents the interface from becoming cold. Muted steel blue provides structure. Bronze is used only as a precise accent. The result should resemble a carefully art-directed editorial service website rather than a template.

Dark mode is the primary and only visual mode in this version. No light-mode switch is introduced.

## 3. Colour system

### Primary surfaces

- Deep ink: `#07111C` — page background
- Ink: `#0B1724` — alternating section background
- Raised ink: `#102033` — restrained cards and highlighted surfaces
- Border blue-black: `#172A40` — structural lines where higher contrast is required

### Text

- Warm cream: `#F5F0E6` — headings and high-priority text
- Soft cream: `#E9E1D3` — body text
- Stone: `#B8B1A7` — metadata and low-priority information

### Accents

- Bronze: `#B58A5A` — primary accent, rules, labels and selected borders
- Light bronze: `#C9A476` — hover and focus states
- Steel blue: `#6E879D` — structural accents
- Light steel blue: `#8DA2B3` — secondary borders and subtle emphasis

### Usage rule

Bronze must occupy only a small minority of the page. It is not a fill colour for large sections and must not be used on every heading. Blue structures the page. Cream carries the content. Ink remains dominant.

No additional bright colour is introduced.

## 4. Typography

### Display and editorial type

Use **Newsreader** where available, with `Georgia` as the fallback.

Applied to:

- hero headline
- section headlines
- selected large statements
- prominent email address

### Interface and body type

Use **Inter**, followed by system sans-serif fallbacks.

Applied to:

- body text
- navigation
- buttons
- labels
- practical information
- legal pages

### Typographic character

- Headlines are sentence case, never all caps.
- Eyebrows may use uppercase with restrained tracking.
- Headline weight remains regular rather than artificially bold.
- Line lengths stay controlled: approximately 38–45rem for body copy.
- Large headlines use tight line-height and modest negative letter-spacing.
- Body copy uses generous line-height and clear paragraph separation.

### Scale

- Hero H1: `clamp(3.25rem, 2rem + 4.8vw, 7.25rem)`
- Section H2: `clamp(2.5rem, 1.8rem + 3vw, 5.2rem)`
- H3: `clamp(1.45rem, 1.25rem + .8vw, 2.1rem)`
- Lead: `clamp(1.15rem, 1.05rem + .4vw, 1.5rem)`
- Body: `clamp(1rem, .96rem + .18vw, 1.125rem)`
- Labels/navigation: approximately `.78–.92rem`

## 5. Layout and grid

- Maximum content width: `90rem`
- Responsive horizontal gutter: `clamp(1rem, 3vw, 3rem)`
- Desktop grid: 12 columns
- Tablet grid: 8 columns
- Mobile: single-column flow
- Standard section spacing: `clamp(5rem, 9vw, 10rem)`
- Major section spacing may reach `clamp(6.5rem, 12vw, 14rem)` only where the story benefits from it

Whitespace must create hierarchy, not emptiness. No section is allowed to look unfinished because content occupies only a small corner of a huge viewport.

## 6. Shape language

The website uses:

- thin rules
- offset editorial grids
- occasional asymmetric alignment
- restrained inset surfaces
- almost no rounded corners

Default border radius is zero. A tiny radius may be used only for technical controls if needed. Large pill buttons and soft app-style cards are prohibited.

Shadows are exceptional. Where required for navigation, they remain dark, broad and low contrast.

## 7. Header and navigation

The header is sticky, compact and semi-transparent with restrained backdrop blur.

Desktop:

- LM signet and/or concise wordmark on the left
- navigation centred or optically balanced
- one understated CTA on the right
- links: Approach, Training, About, Contact

Mobile:

- compact logo
- accessible menu control
- no language switch in this version
- no oversized drawer and no decorative animation

The header CTA uses the fixed wording **Discuss your German goals**.

## 8. Logo and brand presentation

The real LM signet is mandatory. Text-generated substitutes such as a large decorative “LM” are not the logo.

The hierarchy is:

1. LM signet
2. TAILORED GERMAN
3. Lukas Mitzka Education where fuller identification is needed

The signet must remain sharp, undistorted and surrounded by sufficient clear space. It may appear in cream or bronze depending on contrast. It is never placed inside a generic circular badge.

## 9. Image system

### Approved portraits

- Studio portrait: primary hero image
- Arcade portrait: About section

Both must use responsive AVIF sources with WebP fallback and accurate width attributes.

### Treatment

- natural crop, generally 4:5
- no circular portrait masks
- no heavy colour grading
- slight reduction in saturation is allowed to integrate the images into the dark palette
- skin must remain natural
- no blur overlays over the face
- no text placed across the face

### Positioning

Hero portrait:

- visually substantial, not a small card
- integrated into the main grid
- crop prioritises face, upper body and confident posture
- may use a narrow bronze rule as structural separation

About portrait:

- distinct crop or source from the hero
- paired with biography and credentials
- may remain sticky on large screens only if it improves reading and does not create dead space

### Historical motifs

Historical motifs are not a standard content layer. At most one may be used as a very subtle, low-opacity editorial texture if it clearly improves the design. They must not become a gallery or a visual theme competing with the portraits.

## 10. Section-specific composition

### Hero

- two-part editorial composition: copy and portrait
- one strong H1
- short explanatory lead
- one primary CTA
- compact context line such as Vienna / Online may be included
- no second CTA, badge cluster or decorative pseudo-dashboard

### Why tailored

- quieter section after the hero
- one decisive statement and concise explanation
- visual change through alignment, rule or background shift rather than a row of generic cards

### How the programme is planned

- Purpose, Level, Context, Format and Progress appear as one coherent sequence
- displayed vertically in natural reading order
- numbering may be subtle and editorial
- no horizontal “Goal → Programme → Progress” diagram
- no accordion

### Ways to work together

- three clearly differentiated formats
- avoid three identical floating cards
- use alternating composition, rules or restrained panels
- each format receives a clear title, concise explanation and suitable audience
- no separate CTA on every item

### About

- arcade portrait plus concise biography
- credentials are factual and readable
- avoid a wall of badges, logos or inflated authority signals

### Practical fit

- compact information block
- topics such as location, format, suitable clients and next step
- may use a restrained definition-list grid
- this is a filter, not another sales pitch

### Contact

- visually decisive final section
- one direct invitation
- email is prominent
- no complex multi-step form
- WhatsApp is not floating and is not the primary brand interaction

## 11. Buttons and links

Primary CTA:

- transparent or ink background
- 1px bronze border
- cream text
- bronze fill with dark text on hover

Secondary inline links:

- simple text link or subtle underline
- no competing filled style

Rules:

- minimum target size of 44px
- visible focus state using light bronze
- concise labels
- no arrow icon unless it serves navigation clarity

## 12. Motion and transitions

Motion remains subordinate to content.

Allowed:

- restrained reveal on scroll
- small vertical displacement
- opacity transition
- subtle hover transitions on links and buttons

Not allowed:

- parallax portraits
- aggressive scroll hijacking
- horizontal page movement
- animated gradients
- cursor effects
- looping decorative animation
- staggered effects that delay access to content

All motion must respect `prefers-reduced-motion`.

## 13. Responsive behaviour

Desktop composition must not simply shrink. It must reflow deliberately.

- Navigation collapses before it becomes crowded.
- Hero becomes one column on narrow screens.
- Portrait follows the core hero copy and does not push the CTA below excessive empty space.
- Multi-column practical details become one column.
- Sticky imagery is disabled on mobile.
- Headline line breaks are tested at 320px, 375px, 768px, 1024px and wide desktop.
- No horizontal overflow is tolerated.

## 14. Accessibility and legibility

- Contrast must meet WCAG AA for normal text.
- Focus states remain clearly visible.
- Heading order remains logical.
- Portraits receive useful, non-promotional alt text.
- Decorative rules and textures are hidden from assistive technology.
- Text is never embedded inside images.
- Links are identifiable without relying only on colour where context is insufficient.

## 15. Elements explicitly removed from the current design

The following current or historical devices must not survive the rebuild:

- oversized ghost “LM” lettering used as substitute branding
- five separate full-height planning sections
- repeated generic bordered lists
- identical service-card rows
- decorative shapes with no narrative role
- language switcher
- second hero CTA
- standalone process timeline
- floating WhatsApp control
- artificial testimonials or numerical proof
- excessive empty space presented as luxury

## 16. Final design test

Every visual decision must pass four questions:

1. Does it improve understanding or hierarchy?
2. Does it reinforce Tailored German rather than generic premium styling?
3. Does it remain credible for both private and professional clients?
4. Would the page be weaker if the element were removed?

If the fourth answer is no, the element is removed.

## Locked outcome

V3 will use one coherent warm-dark editorial system built from ink, cream, steel blue and restrained bronze. The LM signet, two approved portraits, strong typography, asymmetric but disciplined composition and purposeful spacing provide the visual identity. Variety comes from layout rhythm and image placement, not from adding components or effects.
